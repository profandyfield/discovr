library(parameters)
library(testthat)

test_check("parameters")
