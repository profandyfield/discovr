#' @export
ci.mle <- ci.glm


#' @export
standard_error.mle <- standard_error.mle2


#' @export
model_parameters.mle <- model_parameters.glm
