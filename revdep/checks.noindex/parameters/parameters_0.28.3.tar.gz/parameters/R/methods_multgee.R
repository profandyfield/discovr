#' @export
standard_error.LORgee <- standard_error.default


#' @export
p_value.LORgee <- p_value.default
